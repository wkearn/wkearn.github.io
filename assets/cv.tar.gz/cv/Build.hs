import Development.Shake
import Development.Shake.Command
import Development.Shake.FilePath
import Development.Shake.Util

src = "cv.yaml"
template = "template.tex"
includes = map ("_build"</>) ["includes/moderncvstylewk.sty","includes/plainyr.bst"]
bibs = map ("bibs"</>) ["publications.bib","presentations.bib","inprep.bib","inpress.bib"]
                
main :: IO ()
main = shakeArgs shakeOptions{shakeFiles="_build"} $ do
         want ["_build/cv.pdf"]

         phony "clean" $ do
           putNormal "Cleaning files in _build"
           removeFilesAfter "_build" ["//*"]

         "_build/*.bbl" %> \out -> do
           let outbase = dropExtension out
           need $ [outbase ++ ".aux"]
           cmd "bibtex" outbase
                            
         "_build/cv.tex" %> \out -> do
           need [src,template]
           cmd "pandoc -o" [out] "--template" template src

         "_build/includes/*" %> \out -> do
           need $ [dropDirectory1 out]
           copyFile' (dropDirectory1 out) out
                               
         "_build/cv.out" %> \out -> do
           let tex = "_build/cv.tex"
           need $ tex:includes++bibs
           cmd "pdflatex" tex
               
         "_build/cv.pdf" %> \out -> do
           let tex = "_build/cv.tex"
           need $ tex:includes++bibs
           cmd "pdflatex" [out] tex
